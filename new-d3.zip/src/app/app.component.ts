import { Component, AfterViewInit, ViewChild, ElementRef, OnInit } from '@angular/core';
// import * as d3 from 'd3';
declare var d3: any;
declare var topojson: any;
// import tooltip from 'tooltip';
import * as $ from "jquery";
import { jsondata } from "../app/data";
@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit, AfterViewInit {

    @ViewChild("worldmap")
    public worldmap: ElementRef;

    constructor() { }

    ngOnInit() {
        $("#content").hide();
    }
    customshowTooltip(content, event) {
        $("#content").html(content);
        $("#content").show();
        this.customUpdatePosition(event);
    };

    customUpdatePosition(event) {
        var ttid = "#content";
        var xOffset = -(230 / 2);
        var yOffset = 10;

        var toolTipW = $(ttid).width();
        var toolTipeH = $(ttid).height();
        var windowY = $(window).scrollTop();
        var windowX = $(window).scrollLeft();
        var curX = event.pageX;
        var curY = event.pageY;
        var ttleft = (((curX) < $(window).width() / 2) ? curX - toolTipW - xOffset * 2 : curX + xOffset) - 100;
        if (ttleft < windowX + xOffset) {
            ttleft = windowX + xOffset;
        }
        var tttop = ((curY - windowY + yOffset * 2 + toolTipeH) > $(window).height()) ? curY - toolTipeH - yOffset * 2 : curY + yOffset;
        if (tttop < windowY + yOffset) {
            tttop = curY + yOffset;
        }
        $(ttid).css('top', tttop + 'px').css('left', ttleft + 'px');
    };

    customhideTooltip() {
        $("#content").hide();
    }

    ngAfterViewInit() {

        let worldMapName = this.worldmap.nativeElement.id;
        let worldMapData = jsondata;

        let width = $("#" + worldMapName).width() * 0.95,
           height = $("#" + worldMapName).width() * 0.95 / 1.9;

        let projection = d3.geo.mercator()
        .translate([width / 2, height / 3 * 2])
        .scale(width / 8.5)
            // .center([0, -5.83])
            // .rotate([-8.5, 0])

        let path = d3.geo.path().projection(projection);

        d3.select("#" + worldMapName + " svg").remove();

        let svg = d3.select("#" + worldMapName).append("svg").attr("id", "worldmap_svg").attr("width", width).attr("height", height);
        let countries = svg.append("g").attr("id", "countries"),
            centroids = svg.append("g").attr("id", "centroids"),
            arcs = svg.append("g").attr("id", "arcs");
        let nodeDataByCode = {},
            links = [];
        let magnitudeFormat = d3.format(",.0f"); //gives zero

        countries.selectAll("path").data(topojson.feature(worldMapData.countries, worldMapData.countries.objects.countries).features).enter().append("path").attr("d", path).
            attr("fill-opacity", 0.4).attr("fill", "gray").attr("stroke", "white").append("title").text(function (d) {
                return d.properties.admin + " (" + d.properties.iso_a2 + ")";
            })

        function nodeCoords(node) {
            var lon = parseFloat(node.Lon),
                lat = parseFloat(node.Lat);
            if (isNaN(lon) || isNaN(lat)) {
                return null;
            } else {
                return [lon, lat];
            }
        }

        worldMapData.nodes.forEach(function (node) {
            node.coords = nodeCoords(node);
            node.projection = node.coords ? projection(node.coords) : undefined;
            nodeDataByCode[node.iso_a2] = node;
        });

        worldMapData.shipment_flows.forEach(function (flow?) {
            var o = nodeDataByCode[flow.Origin];
            var co = (o !== undefined) ? o.coords : undefined,
                po = (o !== undefined) ? o.projection : undefined;
            var d = nodeDataByCode[flow.Dest],
                cd = (d !== undefined) ? d.coords : undefined,
                pd = (d !== undefined) ? d.projection : undefined;
            var magnitude = parseFloat(flow.value.toString());
            var reverse_magnitude = parseFloat(flow.reverse.toString());
            if (co && cd && !isNaN(magnitude)) {
                links.push({
                    source: co,
                    target: cd,
                    magnitude: magnitude,
                    reverse_magnitude: reverse_magnitude,
                    origin: o,
                    dest: d,
                    originp: po,
                    destp: pd,
                });
            }
        });

        var zoom = d3.behavior.zoom()
            .scaleExtent([1, 8])
            .on("zoom", function () {
                function scroll_zoom(elements) {
                    elements.forEach(function (element) {
                        element.attr("transform", "translate(" + d3.event.translate.join(",") + ")scale(" + d3.event.scale + ")");
                        if (element === countries) {
                            element.style("stroke-width", 1.0 / d3.event.scale + "px");
                        }
                    });
                }
                scroll_zoom([countries, arcNodes, centroids]);
            });
        svg.call(zoom);

        centroids.selectAll("circle").data(worldMapData.nodes.filter((node) => {
            return worldMapData.shipment_flows.find((flow) => {
                return (flow.Origin === node.iso_a2 || flow.Dest === node.iso_a2) ? true : false;
            })
        })).enter().append("circle").attr("cx", function (d) {
            return d.projection[0]
        }).attr("cy", function (d) {
            return d.projection[1]
        }).attr("r", 2.5).attr("fill", "red").attr("opacity", 1);
        var defs = svg.append("svg:defs");
        // see http://apike.ca/prog_svg_patterns.html
        defs.append("marker").attr("id", "arrowHead").attr("viewBox", "0 0 10 10").attr("refX", 10).attr("refY", 5).attr("orient", "auto")
            .attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 20).attr("markerHeight", 26).append("polyline").attr("points", "0,0 10,5 0,10 1,5").attr("fill", "black");

        var arcTooltips = {
            showDetails: (d, i?) => {
                var unit = "Total shipment weight (kg): ";
                var title = d.origin.Name + " &#10146; " + d.dest.Name;
                var measure = unit + magnitudeFormat(d.magnitude);
                var reverse_measure =unit+( (!isNaN(d.reverse_magnitude)) ? magnitudeFormat(d.reverse_magnitude) : undefined);
                var reverse_title = "\n" + d.dest.Name + " &#10146; " + d.origin.Name;
                var content;
                content = '<p class="main">' + title + '</span></p>';
                content += '<hr class="tooltip-hr">';
                content += '<p class="main">' + measure + '</span></p>';
                if (reverse_measure) {
                    content += '<p class="main">' + reverse_title + '</span></p>';
                    content += '<hr class="tooltip-hr">';
                    content += '<p class="main">' + reverse_measure + '</span></p>';
                }
                if (d.origin.Name) this.customshowTooltip(content, d3.event)
            },
            hideDetails: (d, i?) => {
                this.customhideTooltip();
            }
        };
        var arcNodes = arcs.selectAll("path").data(links).enter().append("path")
            .attr("stroke", "rgb(8, 48, 107)").
            attr("stroke-linecap", "round")
            .attr("stroke-width", function (d?) {
                return 1;
            })
            .attr("d", function (d) {
                return path({
                    type: "LineString",
                    coordinates: [d.source, d.target]
                });
            })

        arcNodes.on("mouseover", function (d) {
            d3.select(this).attr("stroke", "red").attr("marker-end", "url(#arrowHead)").attr("markerWidth", "19").attr('markerHeight', 50);
            arcTooltips.showDetails(d);
        })
        arcNodes.on("mouseout", function (d) {
            d3.select(this).attr("marker-end", "none").attr("stroke", "rgb(8, 48, 107)");

            arcTooltips.hideDetails(d);
        });
    }
}
